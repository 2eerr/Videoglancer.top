/**
 * Shared converted-files card logic (home + result pages).
 */
(function () {
  "use strict";

  const STAGE_DELAY_MS = 400;
  const META_FILE = "outputs_meta.json";

  function formatSize(bytes) {
    if (typeof bytes !== 'number' || !isFinite(bytes) || bytes <= 0) return "0 B";
    var units = ["B", "KB", "MB", "GB", "TB"];
    var i = 0;
    var size = bytes;
    while (size >= 1024 && i < units.length - 1) {
      size /= 1024;
      i++;
    }
    return size.toFixed(i === 0 ? 0 : 1) + " " + units[i];
  }

  function formatMeta(file) {
    const size = formatSize(file.size);
    const ext = (file.filename.split('.').pop() || '').toUpperCase();
    const parts = [size];
    if (ext) parts.push(ext);
    return parts.join(' \u00b7 ');
  }

  function isListable(file) {
    return file.filename !== META_FILE && !file.filename.endsWith("_all_files.zip");
  }

  function showToast(message, type) {
    var container = document.getElementById("toastContainer");
    if (!container) return;
    container.hidden = false;
    var toast = document.createElement("div");
    toast.className = "toast toast--" + (type || "info");
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(function () {
      toast.style.opacity = "0";
      toast.style.transition = "opacity 0.3s";
      setTimeout(function () { toast.remove(); }, 300);
    }, 4000);
  }

  function initIcons() {
    // Icon-only buttons (no text label)
    // Skip injection if SVG is already prerendered in the HTML (server-rendered path).
    const iconBtns = [
      ["btnDownloadAll", "download"],
      ["btnSaveAll", "drive"],
    ];
    iconBtns.forEach(([id, key]) => {
      const el = document.getElementById(id);
      if (!el || el.querySelector("svg")) return;
      if (window.VGIcons) el.insertAdjacentHTML("afterbegin", VGIcons[key]);
    });
  }

  function init() {
    const card = document.getElementById("convertedFilesCard");
    if (!card) return;

    initIcons();

    const filterJobId = card.dataset.jobId || "";
    const isColab = card.dataset.isColab === "true";
    const driveMounted = card.dataset.driveMounted === "true";
    const filesList = document.getElementById("filesList");
    const bulkActions = document.getElementById("bulkActions");
    const fileCount = document.getElementById("cfcFileCount");
    const btnDownloadAll = document.getElementById("btnDownloadAll");
    const btnSaveAll = document.getElementById("btnSaveAll");
    const btnCreateZip = document.getElementById("btnCreateZip");
    const btnDownloadZip = document.getElementById("btnDownloadZip");
    const btnSaveZip = document.getElementById("btnSaveZip");

    let bulkFilesData = [];
    let activeZipJobId = filterJobId || null;
    let activeZipFilename = null;
    let refreshTimer = null;
    function setSaveAllTitle() {
      const t = isColab && driveMounted ? 'Save all to Drive' : 'Mount Drive first';
      btnSaveAll.title = t;
      btnSaveAll.setAttribute('aria-label', t);
    }

    // Render pre-loaded files data synchronously to avoid layout shift.
    // When server-rendered (home page), skip renderFiles() to avoid replacing the
    // already-correct DOM — just populate data + set up UI.
    // When not server-rendered (result page), renderFiles() replaces the placeholder.
    if (window._vgInitialFiles) {
      var _vgData = window._vgInitialFiles;
      window._vgInitialFiles = null;

      if (card.dataset.serverRendered === "true") {
        // Server already rendered the correct HTML — just populate data + setup UI
        var srFiles = (_vgData.files || []).filter(isListable);
        var renderCount = parseInt(card.dataset.renderCount || '0', 10);
        bulkFilesData = srFiles;
        showBulkUI(srFiles.length);
        if (srFiles.length === 0) {
          fileCount.hidden = true;
        }
        applyZipState(_vgData.jobs || {}, filterJobId || zipTargetJobId());
        // Bind drive button events to existing DOM elements
        filesList.querySelectorAll('[data-action="drive"]').forEach(function (btn) {
          btn.addEventListener("click", function () {
            saveOne(btn.dataset.jobId, btn.dataset.filename, btn);
          });
        });
        // Lazy-load remaining files after paint (if server rendered only first N)
        if (srFiles.length > renderCount) {
          var remaining = srFiles.slice(renderCount);
          // Small delay to let the browser paint the initial content first
          setTimeout(function () {
            appendFiles(remaining);
          }, 50);
        }
      } else {
        renderFiles(_vgData);
      }
    }

    function hideBulkUI() {
      bulkActions.hidden = true;
      bulkActions.style.display = "none";
      resetZipButtons();
    }

    function showZipActions() {
      btnCreateZip.hidden = false;
      btnCreateZip.disabled = false;
      btnCreateZip.classList.remove('btn--zip-busy');
      btnDownloadZip.hidden = false;
      btnDownloadZip.removeAttribute('disabled');
      btnDownloadZip.title = "Download Zip";
      btnDownloadZip.setAttribute('aria-label', 'Download Zip');
      btnSaveZip.hidden = false;
      if (isColab && driveMounted) {
        btnSaveZip.disabled = false;
        btnSaveZip.title = "Save Zip to Drive";
        btnSaveZip.setAttribute('aria-label', 'Save Zip to Drive');
      } else {
        btnSaveZip.disabled = true;
        btnSaveZip.title = "Mount Drive first";
        btnSaveZip.setAttribute('aria-label', 'Mount Drive first');
      }
    }

    function showCreateZipOnly() {
      btnCreateZip.hidden = false;
      btnCreateZip.disabled = false;
      btnCreateZip.classList.remove('btn--zip-busy');
      btnCreateZip.title = 'Create Zip';
      btnCreateZip.setAttribute('aria-label', 'Create Zip');
      resetCreateZipIcon();
      btnDownloadZip.hidden = false;
      btnDownloadZip.setAttribute('disabled', '');
      btnDownloadZip.title = "Create zip first";
      btnDownloadZip.setAttribute('aria-label', 'Create zip first');
      btnDownloadZip.dataset.downloadUrl = "";
      btnSaveZip.hidden = false;
      btnSaveZip.disabled = true;
      const saveZipTitle = isColab && driveMounted ? "Create zip first" : "Mount Drive first";
      btnSaveZip.title = saveZipTitle;
      btnSaveZip.setAttribute('aria-label', saveZipTitle);
      activeZipFilename = null;
    }

    function resetCreateZipIcon() {
      const svg = btnCreateZip.querySelector("svg");
      if (svg) svg.remove();
      btnCreateZip.insertAdjacentHTML("afterbegin", VGIcons.archive);
    }

    function showBulkUI(count) {
      fileCount.textContent = String(count);
      fileCount.hidden = false;
      if (count <= 1) {
        hideBulkUI();
        return;
      }
      bulkActions.hidden = false;
      bulkActions.style.display = "";
    }

    function resetZipButtons() {
      showCreateZipOnly();
    }

    // Don't call hideBulkUI() unconditionally — the server already renders the
    // correct initial state (hidden when count <= 1, visible when count > 1).
    // Calling hideBulkUI() here would flash the bulk actions hidden then visible
    // when showBulkUI() runs below, causing a delay in appearance.
    setSaveAllTitle();

    function apiUrl() {
      const base = "/api/files";
      return filterJobId ? `${base}?job_id=${encodeURIComponent(filterJobId)}` : base;
    }

    function uniqueJobIds() {
      return [...new Set(bulkFilesData.map((f) => f.storage_job_id || f.job_id))];
    }

    function zipTargetJobId() {
      if (filterJobId) return filterJobId;
      const ids = uniqueJobIds();
      return ids.length === 1 ? ids[0].split("_video_")[0] : ids[0]?.split("_video_")[0] || null;
    }

    function appendFiles(files) {
      var html = "";
      files.forEach(function (file) {
        const title = file.video_title || file.filename.replace(/ -- \d{14}\.\w+$/, '');
        const isPdf = file.filename.toLowerCase().endsWith('.pdf');
        const driveTitle = isColab && driveMounted ? 'Save to Drive' : 'Mount Drive first';
        const driveBtn = `<button type="button" class="btn btn-icon btn-primary" data-action="drive" data-job-id="${file.storage_job_id || file.job_id}" data-filename="${file.filename}" aria-label="${driveTitle}" title="${driveTitle}" ${isColab && driveMounted ? '' : 'disabled'}>${VGIcons.drive}</button>`;
        const nameHtml = isPdf
          ? `<a href="${file.download_url}" class="cfc-file-name" target="_blank" rel="noopener" title="${title}">${title}</a>`
          : `<span class="cfc-file-name" title="${title}">${title}</span>`;
        html += `
          <div class="cfc-file">
            <div class="cfc-file-meta">
              ${nameHtml}
              <span class="cfc-file-meta-line">${formatMeta(file)}</span>
            </div>
            <div class="cfc-file-actions">
              <a href="${file.download_url}" class="btn btn-icon btn-success" download aria-label="Download" title="Download">${VGIcons.download}</a>
              ${driveBtn}
            </div>
          </div>`;
      });
      filesList.insertAdjacentHTML('beforeend', html);        // Bind drive events for newly added buttons
        filesList.querySelectorAll('[data-action="drive"]').forEach(function (btn) {
          // Avoid re-binding already-bound buttons
          if (btn._vgBound) return;
          btn._vgBound = true;
          btn.addEventListener("click", function () {
            saveOne(btn.dataset.jobId, btn.dataset.filename, btn);
          });
        });
    }

    function renderFiles(data) {
      const files = (data.files || []).filter(isListable);
      bulkFilesData = files;

      if (files.length === 0) {
        filesList.innerHTML =
          '<p class="cfc-empty">No converted files yet</p>';
        hideBulkUI();
        fileCount.hidden = true;
        return;
      }

      let html = "";
      files.forEach((file) => {
        const title = file.video_title || file.filename.replace(/ -- \d{14}\.\w+$/, '');
        const isPdf = file.filename.toLowerCase().endsWith('.pdf');
        const driveTitle = isColab && driveMounted ? 'Save to Drive' : 'Mount Drive first';
        const driveBtn = `<button type="button" class="btn btn-icon btn-primary" data-action="drive" data-job-id="${file.storage_job_id || file.job_id}" data-filename="${file.filename}" aria-label="${driveTitle}" title="${driveTitle}" ${isColab && driveMounted ? '' : 'disabled'}>${VGIcons.drive}</button>`;
        const nameHtml = isPdf
          ? `<a href="${file.download_url}" class="cfc-file-name" target="_blank" rel="noopener" title="${title}">${title}</a>`
          : `<span class="cfc-file-name" title="${title}">${title}</span>`;
        html += `
          <div class="cfc-file">
            <div class="cfc-file-meta">
              ${nameHtml}
              <span class="cfc-file-meta-line">${formatMeta(file)}</span>
            </div>
            <div class="cfc-file-actions">
              <a href="${file.download_url}" class="btn btn-icon btn-success" download aria-label="Download" title="Download">${VGIcons.download}</a>
              ${driveBtn}
            </div>
          </div>`;
      });

      filesList.innerHTML = html;
      showBulkUI(files.length);

      filesList.querySelectorAll('[data-action="drive"]').forEach((btn) => {
        btn.addEventListener("click", () => {
          saveOne(btn.dataset.jobId, btn.dataset.filename, btn);
        });
      });

      applyZipState(data.jobs || {}, filterJobId || zipTargetJobId());
    }

    function applyZipState(jobsMeta, targetId) {
      // Fallback to _global key when the specific job isn't found (home page view)
      const meta = jobsMeta[targetId] || jobsMeta['_global'];
      if (!meta || !meta.zip_filename) {
        showCreateZipOnly();
        return;
      }
      activeZipJobId = targetId || '_global';
      activeZipFilename = meta.zip_filename;
      btnDownloadZip.dataset.downloadUrl = meta.zip_download_url;
      showZipActions();
      if (bulkFilesData.filter(isListable).length > 1) {
        bulkActions.hidden = false;
        bulkActions.style.display = "";
      }
    }

    function loadFiles() {
      fetch(apiUrl())
        .then((r) => r.json())
        .then(renderFiles)
        .catch((err) => console.error("Error loading files:", err));
    }

    function saveOne(storageJobId, filename, btn) {
      if (!isColab) {
        showToast("Google Drive save is only available in Google Colab", "warn");
        return;
      }
      if (!driveMounted) {
        showToast("Google Drive is not mounted. Run the Drive mount cell in Colab first.", "warn");
        return;
      }
      if (btn) btn.disabled = true;
      fetch(`/save-to-drive/${storageJobId}/${encodeURIComponent(filename)}`)
        .then((r) => r.json())
        .then((data) => {
          showToast(data.message, data.success ? "ok" : "error");
        })
        .catch(() => showToast("Failed to save to Google Drive", "error"))
        .finally(() => {
          if (btn) btn.disabled = false;
        });
    }

    function downloadAll() {
      const items = bulkFilesData.filter(isListable);
      items.forEach((file, i) => {
        setTimeout(() => {
          const a = document.createElement("a");
          a.href = file.download_url;
          a.download = file.filename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }, i * STAGE_DELAY_MS);
      });
      showToast(`Downloading ${items.length} file(s)`, "info");
    }

    function saveAll() {
      if (!isColab) {
        showToast("Google Drive save is only available in Google Colab", "warn");
        return;
      }
      if (!driveMounted) {
        showToast("Google Drive is not mounted. Run the Drive mount cell in Colab first.", "warn");
        return;
      }
      const rootId = filterJobId || zipTargetJobId();
      if (!rootId) return;

      btnSaveAll.disabled = true;
      fetch(`/save-all-to-drive/${rootId}`, { method: "POST" })
        .then((r) => r.json())
        .then((data) => {
          showToast(data.message, data.success ? "ok" : "error");
        })
        .catch(() => showToast("Failed to save files to Google Drive", "error"))
        .finally(() => {
          btnSaveAll.disabled = false;
        });
    }

    function createZip() {
      const jobId = filterJobId || zipTargetJobId();
      if (!jobId) {
        showToast("Cannot create zip for multiple jobs", "warn");
        return;
      }
      // Prevent double-clicks while busy (cursor: not-allowed shows visually)
      if (btnCreateZip.classList.contains('btn--zip-busy')) return;

      // Reset state to "no zip" then immediately show spinner
      showCreateZipOnly();
      btnCreateZip.classList.add('btn--zip-busy');
      btnCreateZip.title = 'Creating Zip…';
      btnCreateZip.setAttribute('aria-label', 'Creating Zip…');
      // Replace archive icon directly with spinner (no flicker)
      const archiveSvg = btnCreateZip.querySelector("svg");
      if (archiveSvg) archiveSvg.remove();
      btnCreateZip.insertAdjacentHTML("afterbegin", VGIcons.spinner.replace('<svg', '<svg class="vg-spinner"'));

      fetch(`/create-zip/${jobId}`)
        .then((r) => r.json())
        .then((data) => {
          if (data.success) {
            activeZipJobId = jobId;
            activeZipFilename = data.zip_filename;
            btnDownloadZip.dataset.downloadUrl = `/download/${data.zip_filename}`;
            // Show checkmark briefly, then revert to initial state
            const spin = btnCreateZip.querySelector("svg");
            if (spin) spin.remove();
            btnCreateZip.title = 'Zip created';
            btnCreateZip.setAttribute('aria-label', 'Zip created');
            btnCreateZip.insertAdjacentHTML("afterbegin", VGIcons.check);
            setTimeout(() => {
              btnCreateZip.title = 'Create Zip';
              btnCreateZip.setAttribute('aria-label', 'Create Zip');
              btnCreateZip.disabled = false;
              resetCreateZipIcon();
              showZipActions();
              loadFiles();
            }, 1500);
          } else {
            showToast(data.message || "Failed to create zip", "error");
            showCreateZipOnly();
          }
        })
        .catch(() => {
          showToast("Failed to create zip", "error");
          showCreateZipOnly();
        });
    }

    function saveZip() {
      if (!isColab) {
        showToast("Google Drive save is only available in Google Colab", "warn");
        return;
      }
      if (!driveMounted) {
        showToast("Google Drive is not mounted. Run the Drive mount cell in Colab first.", "warn");
        return;
      }
      if (!activeZipJobId || !activeZipFilename) return;
      btnSaveZip.disabled = true;
      fetch(
        `/save-to-drive/${activeZipJobId}/${encodeURIComponent(activeZipFilename)}`,
      )
        .then((r) => r.json())
        .then((data) => {
          showToast(data.message, data.success ? "ok" : "error");
        })
        .catch(() => showToast("Failed to save zip to Google Drive", "error"))
        .finally(() => {
          btnSaveZip.disabled = false;
        });
    }

    btnDownloadAll.addEventListener("click", downloadAll);
    btnSaveAll.addEventListener("click", saveAll);
    btnCreateZip.addEventListener("click", createZip);
    btnSaveZip.addEventListener("click", saveZip);
    btnDownloadZip.addEventListener("click", function () {
      if (this.disabled) return;
      const url = this.dataset.downloadUrl;
      if (!url) return;
      const a = document.createElement('a');
      a.href = url;
      a.download = '';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    });

    // When server-rendered, skip initial loadFiles() to prevent layout shift.
    // The HTML is already correct from the server — no need to replace it.
    // Polling still runs for updates (new files from other jobs on home page).
    if (card.dataset.serverRendered !== "true") {
      loadFiles();
    }
    refreshTimer = setInterval(loadFiles, filterJobId ? 3000 : 5000);

    window.addEventListener("beforeunload", () => {
      if (refreshTimer) clearInterval(refreshTimer);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

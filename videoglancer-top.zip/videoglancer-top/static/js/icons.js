/**
 * Inline SVG icons (no emojis) — DESIGN.md aligned strokes.
 */
(function (global) {
  "use strict";

  const S =
    'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';

  const icons = {
    download: `<svg width="16" height="16" ${S}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
    upload: `<svg width="16" height="16" ${S}><path d="M17.5 19c0-3.037-2.463-5.5-5.5-5.5S6.5 15.963 6.5 19"/><polyline points="12 12 12 3"/><path d="M9 6l3-3 3 3"/></svg>`,
    drive: `<svg width="16" height="16" viewBox="0 0 207.027 207.027" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M69.866,15.557L0,138.919l28.732,52.552l143.288-0.029l35.008-59.588L136.39,15.735L69.866,15.557z M17.166,139.046 L74.268,38.205L91.21,67.783L33.24,168.447L17.166,139.046z M99.841,82.851l23.805,41.558l-47.732-0.006L99.841,82.851z M163.434,176.443l-117.332,0.024l21.53-37.065l64.606,0.008l0.067,0.119l52.865-0.085L163.434,176.443z M140.932,124.411 L90.157,35.767l-2.966-5.178l40.751,0.121l57.003,93.706L140.932,124.411z"/></svg>`,
    archive: `<svg width="16" height="16" ${S}><path d="M21 8v13H3V8"/><path d="M1 3h22v5H1z"/><path d="M10 12h4"/></svg>`,
    check: `<svg width="16" height="16" ${S}><polyline points="20 6 9 17 4 12"/></svg>`,
    checkCircle: `<svg width="32" height="32" ${S}><circle cx="12" cy="12" r="10"/><polyline points="9 12 11 14 15 10"/></svg>`,
    dot: `<svg width="8" height="8" viewBox="0 0 8 8" fill="currentColor"><circle cx="4" cy="4" r="2"/></svg>`,
    spinner: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v4"/><path d="M12 18v4"/><path d="m4.93 4.93 2.83 2.83"/><path d="m16.24 16.24 2.83 2.83"/><path d="M2 12h4"/><path d="M18 12h4"/><path d="m4.93 19.07 2.83-2.83"/><path d="m16.24 7.76 2.83-2.83"/></svg>`,
  };

  global.VGIcons = icons;
})(typeof window !== "undefined" ? window : globalThis);

"""
PDF generator module using img2pdf + pikepdf.
Each frame is converted to a PDF page in-memory (no recompression),
then assembled with pikepdf for per-page progress reporting.
"""

import os
import io
import logging
from PIL import Image

logger = logging.getLogger(__name__)


def convert_frames_to_pdf(frame_paths_list, target_output_dir, output_filename_base,
                          video_info_dict=None, output_format="pdf",
                          total_frames=0, extraction_method="", quality="",
                          compress_enabled=False, compress_quality=None,
                          actual_quality=None,
                          scene_sensitivity=None, time_interval=None,
                          progress_callback=None):
    """
    Convert extracted frames to PDF.
    Prepends a YouTube-style info page as the first page.
    Reports smooth progress via progress_callback(pct, message).

    Uses img2pdf (JPEG pass-through, no recompression) per-image
    and assembles pages with pikepdf for per-frame progress.

    Returns:
        Path to the generated PDF file, or None on failure
    """
    logger.info("\n" + "=" * 70 + "\nCREATING PDF\n" + "=" * 70)

    if not frame_paths_list:
        logger.error("Error: No frames found to convert to PDF.")
        return None

    os.makedirs(target_output_dir, exist_ok=True)
    output_path = os.path.join(target_output_dir, output_filename_base)

    def _progress(pct, msg=''):
        if progress_callback:
            progress_callback(pct, msg)
        logger.info(f"[PDF BUILD] {pct}% - {msg}")

    _progress(5, 'Generating info page…')

    # --- Generate info page ---
    link_regions = []
    info_img = None
    frame_w = frame_h = 800

    if video_info_dict:
        try:
            from .info_page_generator import create_info_page_image
            if frame_paths_list:
                try:
                    first_frame = Image.open(frame_paths_list[0])
                    frame_w, frame_h = first_frame.size
                    logger.info(f"Detected frame size: {frame_w}x{frame_h}")
                except Exception as e:
                    logger.warning(f"Could not read frame dimensions: {e}")
            info_img, link_regions = create_info_page_image(
                video_info_dict, output_format,
                total_frames, extraction_method, quality,
                page_width=frame_w, page_height=frame_h,
                compress_enabled=compress_enabled,
                compress_quality=compress_quality,
                actual_quality=actual_quality,
                scene_sensitivity=scene_sensitivity,
                time_interval=time_interval,
            )
            logger.info(f"Info page image generated — {info_img.size[0]}x{info_img.size[1]}")
        except Exception as e:
            logger.warning(f"WARNING: Could not generate info page: {e}")

    _progress(10, 'Building PDF pages…')

    import img2pdf
    import pikepdf

    pdf = pikepdf.Pdf.new()
    total = len(frame_paths_list)
    report_every = max(1, total // 50)

    # --- Info page ---
    if info_img:
        buf = io.BytesIO()
        info_img.save(buf, 'JPEG', quality=95)
        buf.seek(0)
        pdf_bytes = img2pdf.convert(buf)
        src = pikepdf.Pdf.open(io.BytesIO(pdf_bytes))
        pdf.pages.extend(src.pages)
        src.close()

    # --- Frame pages ---
    for i, frame_path in enumerate(frame_paths_list):
        pdf_bytes = img2pdf.convert(frame_path)
        src = pikepdf.Pdf.open(io.BytesIO(pdf_bytes))
        pdf.pages.extend(src.pages)
        src.close()

        if (i + 1) % report_every == 0 or i == total - 1:
            pct = 10 + int((i + 1) / total * 83)
            _progress(pct, f'Adding page {i+1}/{total}')

    # --- Add clickable link annotations to the first page ---
    if link_regions and info_img:
        try:
            info_img_h = info_img.height
            info_img_w = info_img.width
            pdf_page = pdf.pages[0]
            mb = pdf_page.MediaBox
            pdf_w = float(mb[2]) - float(mb[0])
            pdf_h = float(mb[3]) - float(mb[1])
            scale_x = pdf_w / info_img_w
            scale_y = pdf_h / info_img_h

            annots = []
            for x0, y0, x1, y1, url in link_regions:
                sx0 = x0 * scale_x
                sy0 = y0 * scale_y
                sx1 = x1 * scale_x
                sy1 = y1 * scale_y
                pdf_y0 = pdf_h - sy1
                pdf_y1 = pdf_h - sy0
                ann = pikepdf.Dictionary()
                ann['/Type'] = pikepdf.Name.Annot
                ann['/Subtype'] = pikepdf.Name.Link
                ann['/Rect'] = [sx0, pdf_y0, sx1, pdf_y1]
                ann['/Border'] = [0, 0, 0]
                a = pikepdf.Dictionary()
                a['/S'] = pikepdf.Name.URI
                a['/URI'] = url
                a['/NewWindow'] = pikepdf.Boolean(True)
                ann['/A'] = a
                annots.append(ann)
            pdf_page['/Annots'] = pdf.make_indirect(pikepdf.Array(annots))
            logger.info(f"Added {len(link_regions)} clickable link(s) to PDF first page.")
        except Exception as e:
            logger.warning(f"Could not add clickable links to PDF: {e}")

    _progress(94, 'Writing PDF file…')
    pdf.save(output_path)
    pdf.close()

    file_size = os.path.getsize(output_path) / (1024 * 1024)
    logger.info(f"Total pages: {1 + total} (1 info page + {total} frames)")
    logger.info(f"File size: {file_size:.2f} MB")
    logger.info(f"PDF created: {output_filename_base}")
    logger.info(f"Location: {output_path}")
    _progress(100, 'Done')

    logger.info("=" * 70)
    return output_path
